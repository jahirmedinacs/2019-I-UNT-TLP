		</div>
    </div>
    <?php
    for ($ii=0; $ii<10; $ii++){
        echo("</br>");
    }    
    ?>
    <center>
        <div>
            Conexion Realizada con la Base de Datos <b>Ventas</b> mediante el usario
            </br>
            <i><b>tlp_query</b></i> con clave <i><b>1234</b></i>
        </div>
    </center>
</body>
</html>
